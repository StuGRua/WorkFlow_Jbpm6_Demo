package com.sample;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.jbpm.test.JbpmJUnitBaseTestCase;
import org.junit.Test;
import org.kie.api.KieServices;
import org.kie.api.logger.KieRuntimeLogger;
import org.kie.api.runtime.KieSession;
import org.kie.api.runtime.manager.RuntimeEngine;
import org.kie.api.runtime.manager.RuntimeManager;
import org.kie.api.runtime.process.ProcessInstance;
import org.kie.api.task.TaskService;
import org.kie.api.task.model.TaskSummary;


/**
 * This is a sample test of the evaluation process.
 */
public class ProcessTest extends JbpmJUnitBaseTestCase {
	
	public ProcessTest() {
		super(true, true);
	}	

	@Test
	public void testEvaluationProcess() {
		
		RuntimeManager manager = createRuntimeManager("Evaluation.bpmn");
		RuntimeEngine engine = getRuntimeEngine(null);
		KieSession ksession = engine.getKieSession();
		TaskService taskService = engine.getTaskService();
		
		// start a new process instance
		
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("employee", "krisv");
		params.put("Pre", 1);
		params.put("YN", 1);
		ProcessInstance processInstance = 
			ksession.startProcess("com.sample.evaluation", params);
		
		// complete Self Evaluation
		List<TaskSummary> tasks = taskService.getTasksAssignedAsPotentialOwner("krisv", "en-UK");
		TaskSummary task = tasks.get(0);
		
		  System.out.println("krisv"+" is doing task " + task.getName() + ": " + task.getDescription());
		  taskService.start(task.getId(), "krisv");
		  Map<String, Object> results = new HashMap<String, Object>();
		  results.put("Pre", 1);
		  taskService.complete(task.getId(), "krisv", results);

		  tasks = taskService.getTasksAssignedAsPotentialOwner("krisv", "en-UK");
		  task = tasks.get(0);
			
			  System.out.println("krisv"+" is doing task " + task.getName() + ": " + task.getDescription());
			  taskService.start(task.getId(), "krisv");
			  results = new HashMap<String, Object>();
			  results.put("YN", 1);
			  taskService.complete(task.getId(), "krisv", results);
		
		System.out.println("Process is completed");
		
		manager.disposeRuntimeEngine(engine);
		manager.close();
	}

	
}
